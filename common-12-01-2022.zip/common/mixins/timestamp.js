module.exports = function(Model, options) {
    

  }