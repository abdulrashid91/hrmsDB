'use strict';

module.exports = function(Color) {

};
