'use strict';

module.exports = function(Bacheckoutdata) {

 
    Bacheckoutdata.remoteMethod("ImportExcellData", {
        description: "Import Data from  Excell Sheet .", 
        http: {path:'/ImportExcellData', verb: 'get'} ,    
        returns: {
          type: "array",
          root: true,
        },
       
      });

      Bacheckoutdata.ImportExcellData =  function (cb) {
      
        const reader = require('xlsx') ;           
      //const file = reader.readFile('./financial-actions_ent_zjcxwvqwxpyuhc64y2p6j6332e_20211221_20211222_1 - Copy.csv');
       const file = reader.readFile('./financial-actions_ent_zjcxwvqwxpyuhc64y2p6j6332e_20211221_20211222_1.csv');
    
        const data = [];        
        const sheets = file.SheetNames;        
        for(let i = 0; i < sheets.length; i++)
        {
           const temp = reader.utils.sheet_to_json(
                file.Sheets[file.SheetNames[i]])
                const totalRowsCount = temp.length;
                let rowCount = 0;
           temp.forEach((res) => {  
          //temp.eachSeries(temp, async (res) => {  
             
            let subEntityId = '';
            let subEntityName = '' ;
            let currencyAccountCustomId = '';
            let fxTradeId = '';
            let payoutId = '';
            let reference ='';
            let midd = '';
            let entityCountryTaxCurrency = '';
            let taxFxRate ='';
            let taxCurrencyAmount = '';
            let requestedOn = '';
           // let requestedOn = new Date(Date.now());
            rowCount = rowCount+1;

            if(res['Sub Entity ID']==null || res['Sub Entity ID']==undefined)
           {
                subEntityId = '';

           }
          else
            {
              subEntityId = res['Sub Entity ID'];
            }

            if(res['Sub Entity Name']==null || res['Sub Entity Name']==undefined)
           {
                subEntityName = '';

           }
          else
            {
              subEntityName = res['Sub Entity Name'];
            }
            
            if(res['Currency Account Custom ID']==null || res['Currency Account Custom ID']==undefined)
            {
              currencyAccountCustomId = '';
 
            }
           else
             {
              currencyAccountCustomId = res['Currency Account Custom ID'];
             }

            if(res['FX Trade ID']==null || res['FX Trade ID']==undefined)
            {
              fxTradeId = '';
 
            }
           else
             {
              fxTradeId = res['FX Trade ID'];
             }

             if(res['Payout ID']==null || res['Payout ID']==undefined)
            {
              payoutId = '';
 
            }
           else
             {
              payoutId = res['Payout ID'];
             }

             if(res['reference']==null || res['reference']==undefined)
             {
              reference = '';
  
             }
            else
              {
                reference = res['reference'];
              }

              if(res['MID']==null || res['MID']==undefined)
              {
                midd = '';
   
              }
             else
               {
                midd = res['MID'];
               }
              
               if(res['Entity Country Tax Currency']==null || res['Entity Country Tax Currency']==undefined)
               {
                 entityCountryTaxCurrency = '';
    
               }
              else
                {
                  entityCountryTaxCurrency = res['Entity Country Tax Currency'];
                }
                if(res['Tax Fx Rate']==null || res['Tax Fx Rate']==undefined)
               {
                 taxFxRate = '';
    
               }
              else
                {
                  taxFxRate = res['Tax Fx Rate'];
                }

                if(res['Tax Currency Amount']==null || res['Tax Currency Amount']==undefined)
               {
                 taxCurrencyAmount = '';
    
               }
              else
                {
                  taxCurrencyAmount = res['Tax Currency Amount'];
                }
                if(res['Requested On']==null || res['Requested On']==undefined)
               {
                 requestedOn = '';
    
               }
              else
                {
                  requestedOn = res['Requested On'];
                }
try 
         { 
           
           Bacheckoutdata.create([
             {clientEntityId: res['Client Entity ID'], clientEntityName: res['Client Entity Name'], subEntityId: subEntityId , subEntityName: subEntityName ,processingChannelId: res['Processing Channel ID'],merchantCategoryCode: res['Merchant Category Code'],currencyAccountId: res['Currency Account ID'], currencyAccountName: res['Currency Account Name'],currencyAccountCustomId: currencyAccountCustomId, actionType: res['Action Type'],actionId: res['Action ID'], paymentId: res['Payment ID'], requestedOn: requestedOn, processedOn: res['Processed On'],
             processingCurrency: res['Processing Currency'],fxRateApplied:res['FX Rate Applied'], holdingCurrency: res['Holding Currency'], fxTradeId: fxTradeId, payoutId: payoutId, reference: reference, paymentMethod:res['Payment Method'],cardType: res['Card Type'], cardCategory: res['Card Category'], issuerCountry: res['Issuer Country'], entityCountry: res['Entity Country'], region: res['Region'], mid: midd, responseCode: res['Response Code'], responseDescription: res['Response Description'], breakdownType: res['Breakdown Type'], processingCurrencyAmount: res['Processing Currency Amount'], entityCountryTaxCurrency: entityCountryTaxCurrency, taxFxRate: taxFxRate, taxCurrencyAmount:taxCurrencyAmount,recordStatus :'Processed'
            }            
          ], function(err, tData) {
             if (err) throw err;
            data.push(tData);
        });
      }
      catch(err)
      {
          console.log(err);
      }
      // if(totalRowsCount===rowCount)
      // {
      //   cb(null, data);    
      //  }
    })   
   
   
       }   //// End of For Loop 
       cb(null, data);    
    };

};