'use strict';

module.exports = function(Mytable) {

};
