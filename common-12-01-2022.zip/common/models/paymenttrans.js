'use strict';

module.exports = function(Paymenttrans) {

    // Paymenttrans.remoteMethod("ReadExcellData", {
    //     description: "Read Excell Sheet Data.",      
    //     returns: {
    //       type: "array",
    //       root: true,
    //     },
    //   });

    //   Paymenttrans.ReadExcellData = function (cb) {
    
    //     const reader = require('xlsx') ; 
    //     // Reading our test file
    //    // const file = reader.readFile('./Book1.xlsx');    
    //    const file = reader.readFile('./financial-actions_ent_zjcxwvqwxpyuhc64y2p6j6332e_20211221_20211222_1 - Copy.csv');
    
    //     let data = [];
        
    //     const sheets = file.SheetNames;
    //     console.log(sheets); 
       
    //     for(let i = 0; i < sheets.length; i++)
    //     {
    //        const temp = reader.utils.sheet_to_json(
    //             file.Sheets[file.SheetNames[i]])
    //        temp.forEach((res) => {  
    
    //         Paymenttrans.find({ where: {transactionId: res['Payment ID']}}, function (error, tdata) {              
                        
    //           if(tdata.length>0 &&( tdata[0].processingFee==null || tdata[0].processingFee==''))
    //           {              
    //             let odata = {
    //             processingFee:  res['Processing Currency Amount']       
    //           };              
    //           let whereData = { transactionId: res['Payment ID'] };  
    //           Paymenttrans.updateAll(whereData,odata, function (err, _odata) {       
    //     }); // End of Paymenttrans Update Function
        
    //      }         
              
    //         }); /// end of Paymenttrans Find  Function     
            
    //         data.push(res);
              
    //        })
    //     }      
    //     // Printing data   
    //     cb(null, data);
     
    //    };

    Paymenttrans.remoteMethod("ProcessExcellData", {
        description: "Process Excell Sheet Data.",      
        returns: {
          type: "array",
          root: true,
        },
      });

        Paymenttrans.ProcessExcellData = function (cb) {
         try 
         {
          let sql ="select * from bacheckoutdata where recordStatus = 'Processed' order by paymentId";
          Paymenttrans.dataSource.connector.query(sql, (err, tData) => {           
             if (err) {
              cb(null, err);
            } 
            else if(tData.length>0) {
              
            for(let i = 0; i < tData.length; i++){
              
               Paymenttrans.find({ where: {transactionId: tData[i]['paymentId'] } },function (error, tdata) { 

                let sql_query ="select paymentId,sum(processingCurrencyAmount)amount from bacheckoutdata where paymentId ='" + tData[i]['paymentId'] + "' and bacheckoutdata.recordStatus = 'Processed'" ;

                Paymenttrans.dataSource.connector.query(sql_query, (err, dataResult) => {
                  
                  Paymenttrans.updateAll({transactionId: dataResult[0].paymentId},{processingFee : dataResult[0].amount},function(err,_odata)
                  {
                   
                   let update_status ="update bacheckoutdata set recordStatus = 'Completed'  where  paymentId = '" + dataResult[0].paymentId + "'" ;

                   Paymenttrans.dataSource.connector.query(update_status, (err, statusResult) => {
                   
                   });

                  });


                });
              });  

            }
            cb(null, tData);
            } 
            else
            {
              cb(null, "Records Not Found for that Operation..!");
            }
          });    
        }
        catch(err)
{
    console.log("Error :"+ err);
}
       };

};
