'use strict';

module.exports = function(Regions) {

};
